import React, { useState, useMemo } from 'react';
import {
  BarChart3,
  TrendingUp,
  DollarSign,
  Users,
  Award,
  Calendar,
  Filter,
  Download,
  Printer,
  PieChart as PieIcon,
  CheckCircle,
  Scissors,
  ArrowUpRight,
  Receipt,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
  AreaChart,
  Area,
} from 'recharts';
import {
  Company,
  Branch,
  BusinessUnit,
  Staff,
  Service,
  VisitSession,
  CommissionLog,
  ExpenseRecord,
} from '../types';

interface ReportsDashboardProps {
  company: Company;
  branches: Branch[];
  businessUnits: BusinessUnit[];
  staffList: Staff[];
  services: Service[];
  visitSessions: VisitSession[];
  commissionLogs: CommissionLog[];
  expenses: ExpenseRecord[];
}

const COLORS = ['#5A5A40', '#8B8B6B', '#2D2D2A', '#C2A649', '#737366', '#A39171'];

export const ReportsDashboard: React.FC<ReportsDashboardProps> = ({
  company,
  branches,
  businessUnits,
  staffList,
  services,
  visitSessions,
  commissionLogs,
  expenses,
}) => {
  const [selectedBranchId, setSelectedBranchId] = useState<string>('all');
  const [timeRange, setTimeRange] = useState<'today' | 'week' | 'month' | 'all'>('all');

  // Filter visit sessions by company & selected branch
  const companyVisits = useMemo(() => {
    return visitSessions.filter((s) => {
      if (s.companyId !== company.id) return false;
      if (selectedBranchId !== 'all' && s.branchId !== selectedBranchId) return false;
      return true;
    });
  }, [visitSessions, company.id, selectedBranchId]);

  const companyCommissions = useMemo(() => {
    return commissionLogs.filter((c) => {
      if (c.companyId !== company.id) return false;
      if (selectedBranchId !== 'all' && c.branchId !== selectedBranchId) return false;
      return true;
    });
  }, [commissionLogs, company.id, selectedBranchId]);

  const companyExpenses = useMemo(() => {
    return expenses.filter((e) => {
      if (e.companyId !== company.id) return false;
      if (selectedBranchId !== 'all' && e.branchId !== selectedBranchId) return false;
      return true;
    });
  }, [expenses, company.id, selectedBranchId]);

  // Key KPI Calculations
  const completedVisits = companyVisits.filter((s) => s.status === 'completed');
  const totalGrossRevenue = completedVisits.reduce((acc, s) => acc + s.netTotalEtb, 0);
  const totalCommissionsEarned = companyCommissions.reduce((acc, c) => acc + c.commissionAmountEtb, 0);
  const totalExpensesAmount = companyExpenses.reduce((acc, e) => acc + e.amountEtb, 0);
  const netProfit = totalGrossRevenue - totalCommissionsEarned - totalExpensesAmount;
  const avgTicketValue = completedVisits.length > 0 ? Math.round(totalGrossRevenue / completedVisits.length) : 0;

  // Daily Sales & Revenue Trend Data
  const dailySalesData = useMemo(() => {
    const map: Record<string, { date: string; revenue: number; visits: number }> = {};

    completedVisits.forEach((session) => {
      const dateStr = session.startedAt ? session.startedAt.split('T')[0] : 'Today';
      if (!map[dateStr]) {
        map[dateStr] = { date: dateStr, revenue: 0, visits: 0 };
      }
      map[dateStr].revenue += session.netTotalEtb;
      map[dateStr].visits += 1;
    });

    // If empty, supply placeholder
    if (Object.keys(map).length === 0) {
      return [
        { date: '2026-08-01', revenue: 4200, visits: 3 },
        { date: '2026-08-02', revenue: 6800, visits: 5 },
        { date: '2026-08-03', revenue: 5100, visits: 4 },
        { date: '2026-08-04', revenue: 8900, visits: 7 },
        { date: '2026-08-05', revenue: 11200, visits: 9 },
        { date: '2026-08-06', revenue: totalGrossRevenue || 9400, visits: completedVisits.length || 8 },
      ];
    }

    return Object.values(map).sort((a, b) => a.date.localeCompare(b.date));
  }, [completedVisits, totalGrossRevenue]);

  // Service Category Breakdown (Pie Chart)
  const categoryData = useMemo(() => {
    const map: Record<string, number> = {};

    completedVisits.forEach((session) => {
      session.services.forEach((srvItem) => {
        const matchingSrv = services.find((s) => s.id === srvItem.serviceId);
        const cat = matchingSrv?.category || 'General Services';
        map[cat] = (map[cat] || 0) + srvItem.priceEtb;
      });
    });

    const result = Object.keys(map).map((catName) => ({
      name: catName,
      value: map[catName],
    }));

    if (result.length === 0) {
      return [
        { name: 'Haircut & Styling', value: 12500 },
        { name: 'Massage & Spa', value: 9800 },
        { name: 'Facial & Skincare', value: 5400 },
        { name: 'Manicure & Nails', value: 3200 },
      ];
    }
    return result;
  }, [completedVisits, services]);

  // Payment Method Distribution Data
  const paymentMethodData = useMemo(() => {
    const map: Record<string, number> = {
      telebirr: 0,
      cbe_birr: 0,
      cash: 0,
      card: 0,
    };

    completedVisits.forEach((session) => {
      const pm = session.paymentMethod || 'telebirr';
      map[pm] = (map[pm] || 0) + session.netTotalEtb;
    });

    return [
      { name: 'Telebirr', amount: map.telebirr },
      { name: 'CBE Birr', amount: map.cbe_birr },
      { name: 'Cash', amount: map.cash },
      { name: 'Card / POS', amount: map.card },
    ].filter((item) => item.amount > 0);
  }, [completedVisits]);

  // Staff Performance Ranking
  const staffPerformance = useMemo(() => {
    const map: Record<
      string,
      {
        staffId: string;
        staffName: string;
        role: string;
        servicesCompleted: number;
        revenueGenerated: number;
        commissionEarned: number;
      }
    > = {};

    completedVisits.forEach((session) => {
      session.services.forEach((srv) => {
        if (!map[srv.staffId]) {
          const stf = staffList.find((s) => s.id === srv.staffId);
          map[srv.staffId] = {
            staffId: srv.staffId,
            staffName: srv.staffName,
            role: stf?.role || 'Provider',
            servicesCompleted: 0,
            revenueGenerated: 0,
            commissionEarned: 0,
          };
        }
        map[srv.staffId].servicesCompleted += 1;
        map[srv.staffId].revenueGenerated += srv.priceEtb;
        map[srv.staffId].commissionEarned += srv.commissionEarnedEtb;
      });
    });

    return Object.values(map).sort((a, b) => b.revenueGenerated - a.revenueGenerated);
  }, [completedVisits, staffList]);

  // Service Popularity Ranking
  const servicePopularity = useMemo(() => {
    const map: Record<
      string,
      { serviceName: string; category: string; priceEtb: number; count: number; totalRevenue: number }
    > = {};

    completedVisits.forEach((session) => {
      session.services.forEach((srv) => {
        if (!map[srv.serviceId]) {
          const s = services.find((item) => item.id === srv.serviceId);
          map[srv.serviceId] = {
            serviceName: srv.serviceName,
            category: s?.category || 'General',
            priceEtb: srv.priceEtb,
            count: 0,
            totalRevenue: 0,
          };
        }
        map[srv.serviceId].count += 1;
        map[srv.serviceId].totalRevenue += srv.priceEtb;
      });
    });

    return Object.values(map).sort((a, b) => b.totalRevenue - a.totalRevenue);
  }, [completedVisits, services]);

  const handleExportCsv = () => {
    const rows = [
      ['Date', 'Customer', 'Queue No', 'Net Total (ETB)', 'Payment Method', 'Status'],
      ...completedVisits.map((v) => [
        v.startedAt?.split('T')[0] || '',
        v.customerName,
        v.queueNumber,
        v.netTotalEtb.toString(),
        v.paymentMethod || 'telebirr',
        v.status,
      ]),
    ];

    const csvContent = 'data:text/csv;charset=utf-8,' + rows.map((e) => e.join(',')).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `${company.name.replace(/\s+/g, '_')}_sales_report.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div id="reports-dashboard-root" className="space-y-6">
      {/* Top Header & Filter Controls */}
      <div className="bg-white rounded-3xl p-6 border border-[#e5e5d1] shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <BarChart3 className="w-6 h-6 text-[#5A5A40]" />
            <h2 className="text-xl font-serif font-bold text-[#2d2d2a]">
              Reports & Executive Analytics Dashboard
            </h2>
          </div>
          <p className="text-xs text-[#737366] mt-1">
            Real-time daily sales, staff commissions, service popularity, and branch revenue summaries for{' '}
            <strong className="text-[#2d2d2a]">{company.name}</strong>.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Branch Select */}
          <div className="flex items-center space-x-1.5 bg-[#f5f5f0] border border-[#e5e5d1] rounded-2xl px-3 py-2 text-xs">
            <Filter className="w-4 h-4 text-[#737366]" />
            <select
              value={selectedBranchId}
              onChange={(e) => setSelectedBranchId(e.target.value)}
              className="bg-transparent font-medium text-[#2d2d2a] focus:outline-none cursor-pointer"
            >
              <option value="all">All Branches</option>
              {branches
                .filter((b) => b.companyId === company.id)
                .map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name} ({b.city})
                  </option>
                ))}
            </select>
          </div>

          {/* Time Range Switch */}
          <div className="flex items-center bg-[#f5f5f0] border border-[#e5e5d1] rounded-2xl p-1 text-xs">
            {(['today', 'week', 'month', 'all'] as const).map((range) => (
              <button
                key={range}
                onClick={() => setTimeRange(range)}
                className={`px-3 py-1.5 rounded-xl font-medium transition cursor-pointer capitalize ${
                  timeRange === range
                    ? 'bg-[#5A5A40] text-white shadow-sm'
                    : 'text-[#737366] hover:text-[#2d2d2a]'
                }`}
              >
                {range}
              </button>
            ))}
          </div>

          {/* Export Actions */}
          <button
            onClick={handleExportCsv}
            className="flex items-center space-x-1.5 bg-[#2d2d2a] hover:bg-[#1c1c19] text-white font-bold px-4 py-2 rounded-2xl text-xs transition shadow-sm cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Gross Revenue */}
        <div className="bg-white rounded-3xl p-5 border border-[#e5e5d1] shadow-sm space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-xs font-bold text-[#737366] uppercase tracking-wider">Gross Sales Revenue</span>
            <div className="w-8 h-8 rounded-full bg-[#f5f5f0] flex items-center justify-center text-[#5A5A40]">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-serif font-bold text-[#2d2d2a]">
            {totalGrossRevenue.toLocaleString()} <span className="text-xs font-sans text-[#737366]">ETB</span>
          </div>
          <div className="flex items-center text-[11px] text-[#5A5A40] space-x-1 font-medium">
            <TrendingUp className="w-3.5 h-3.5" />
            <span>{completedVisits.length} visits completed</span>
          </div>
        </div>

        {/* Avg Ticket Value */}
        <div className="bg-white rounded-3xl p-5 border border-[#e5e5d1] shadow-sm space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-xs font-bold text-[#737366] uppercase tracking-wider">Avg Invoice Value</span>
            <div className="w-8 h-8 rounded-full bg-[#f5f5f0] flex items-center justify-center text-[#5A5A40]">
              <Receipt className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-serif font-bold text-[#2d2d2a]">
            {avgTicketValue.toLocaleString()} <span className="text-xs font-sans text-[#737366]">ETB</span>
          </div>
          <div className="text-[11px] text-[#737366]">Per visit transaction average</div>
        </div>

        {/* Staff Commissions */}
        <div className="bg-white rounded-3xl p-5 border border-[#e5e5d1] shadow-sm space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-xs font-bold text-[#737366] uppercase tracking-wider">Staff Commissions</span>
            <div className="w-8 h-8 rounded-full bg-[#f5f5f0] flex items-center justify-center text-amber-700">
              <Award className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-serif font-bold text-[#2d2d2a]">
            {totalCommissionsEarned.toLocaleString()} <span className="text-xs font-sans text-[#737366]">ETB</span>
          </div>
          <div className="text-[11px] text-[#737366]">Accrued provider payouts</div>
        </div>

        {/* Net Profit */}
        <div className="bg-white rounded-3xl p-5 border border-[#e5e5d1] shadow-sm space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-xs font-bold text-[#737366] uppercase tracking-wider">Net Operating Surplus</span>
            <div className="w-8 h-8 rounded-full bg-[#f5f5f0] flex items-center justify-center text-emerald-700">
              <CheckCircle className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-serif font-bold text-[#2d2d2a]">
            {netProfit.toLocaleString()} <span className="text-xs font-sans text-[#737366]">ETB</span>
          </div>
          <div className="text-[11px] text-emerald-700 font-semibold">After commissions & expenses</div>
        </div>
      </div>

      {/* Charts Grid Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Daily Revenue Trend Chart (8 Cols) */}
        <div className="lg:col-span-8 bg-white rounded-3xl p-6 border border-[#e5e5d1] shadow-sm space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-base font-serif font-bold text-[#2d2d2a]">Daily Revenue & Visit Trend</h3>
              <p className="text-xs text-[#737366]">Gross revenue collected per day in Ethiopian Birr (ETB)</p>
            </div>
            <span className="text-xs px-2.5 py-1 rounded-full bg-[#f5f5f0] text-[#5A5A40] font-bold border border-[#e5e5d1]">
              Daily Breakdown
            </span>
          </div>

          <div className="h-64 w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={dailySalesData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e5d1" />
                <XAxis dataKey="date" stroke="#737366" fontSize={11} tickLine={false} />
                <YAxis stroke="#737366" fontSize={11} tickLine={false} />
                <Tooltip
                  formatter={(value: any) => [`${Number(value).toLocaleString()} ETB`, 'Revenue']}
                  contentStyle={{
                    backgroundColor: '#2d2d2a',
                    color: '#f5f5f0',
                    borderRadius: '12px',
                    fontSize: '12px',
                  }}
                />
                <Bar dataKey="revenue" fill="#5A5A40" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Service Popularity Pie Chart (4 Cols) */}
        <div className="lg:col-span-4 bg-white rounded-3xl p-6 border border-[#e5e5d1] shadow-sm flex flex-col justify-between space-y-4">
          <div>
            <h3 className="text-base font-serif font-bold text-[#2d2d2a]">Service Category Revenue</h3>
            <p className="text-xs text-[#737366]">Distribution across service categories</p>
          </div>

          <div className="h-52 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryData}
                  dataKey="value"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  innerRadius={45}
                  outerRadius={75}
                  paddingAngle={4}
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(val: any) => [`${Number(val).toLocaleString()} ETB`, 'Sales']}
                  contentStyle={{
                    backgroundColor: '#2d2d2a',
                    color: '#f5f5f0',
                    borderRadius: '12px',
                    fontSize: '11px',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          {/* Legend */}
          <div className="space-y-1.5 pt-2 border-t border-[#e5e5d1]">
            {categoryData.slice(0, 4).map((item, idx) => (
              <div key={idx} className="flex justify-between items-center text-xs">
                <div className="flex items-center space-x-2">
                  <span
                    className="w-2.5 h-2.5 rounded-full"
                    style={{ backgroundColor: COLORS[idx % COLORS.length] }}
                  />
                  <span className="text-[#2d2d2a] font-medium">{item.name}</span>
                </div>
                <span className="font-mono font-bold text-[#5A5A40]">{item.value.toLocaleString()} ETB</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Staff Performance KPIs Table */}
      <div className="bg-white rounded-3xl p-6 border border-[#e5e5d1] shadow-sm space-y-4">
        <div className="flex justify-between items-center">
          <div>
            <h3 className="text-base font-serif font-bold text-[#2d2d2a]">Staff Performance & Commission Leaderboard</h3>
            <p className="text-xs text-[#737366]">Completed services, total sales contribution, and commission earned per provider</p>
          </div>
          <span className="text-xs text-[#737366] font-mono">
            {staffPerformance.length} Providers Tracked
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-[#e5e5d1] text-[#737366] font-bold uppercase tracking-wider">
                <th className="py-3 px-3">Staff Member</th>
                <th className="py-3 px-3">Role</th>
                <th className="py-3 px-3 text-center">Services Done</th>
                <th className="py-3 px-3 text-right">Revenue Generated</th>
                <th className="py-3 px-3 text-right">Commission Earned</th>
                <th className="py-3 px-3 text-right">Avg / Service</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#e5e5d1]/60 text-[#2d2d2a]">
              {staffPerformance.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-[#737366]">
                    No completed service data recorded yet for this selection.
                  </td>
                </tr>
              ) : (
                staffPerformance.map((stf, index) => {
                  const avgPerSrv = stf.servicesCompleted > 0 ? Math.round(stf.revenueGenerated / stf.servicesCompleted) : 0;
                  return (
                    <tr key={stf.staffId} className="hover:bg-[#f5f5f0]/60 transition">
                      <td className="py-3 px-3 font-bold flex items-center space-x-2">
                        {index === 0 && <Award className="w-4 h-4 text-amber-500 shrink-0" />}
                        <span>{stf.staffName}</span>
                      </td>
                      <td className="py-3 px-3 capitalize text-[#737366]">{stf.role}</td>
                      <td className="py-3 px-3 text-center font-mono font-bold">{stf.servicesCompleted}</td>
                      <td className="py-3 px-3 text-right font-mono font-bold text-[#2d2d2a]">
                        {stf.revenueGenerated.toLocaleString()} ETB
                      </td>
                      <td className="py-3 px-3 text-right font-mono font-bold text-[#5A5A40]">
                        {stf.commissionEarned.toLocaleString()} ETB
                      </td>
                      <td className="py-3 px-3 text-right font-mono text-[#737366]">
                        {avgPerSrv.toLocaleString()} ETB
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Top Performing Services List */}
      <div className="bg-white rounded-3xl p-6 border border-[#e5e5d1] shadow-sm space-y-4">
        <h3 className="text-base font-serif font-bold text-[#2d2d2a]">Most Popular & High-Margin Services</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {servicePopularity.slice(0, 6).map((srv, idx) => (
            <div key={idx} className="p-4 bg-[#f5f5f0] rounded-2xl border border-[#e5e5d1] space-y-2">
              <div className="flex justify-between items-start">
                <div>
                  <div className="font-bold text-sm text-[#2d2d2a]">{srv.serviceName}</div>
                  <span className="text-[10px] text-[#737366] font-medium uppercase tracking-wider">{srv.category}</span>
                </div>
                <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-full bg-white border border-[#e5e5d1] text-[#5A5A40]">
                  #{idx + 1}
                </span>
              </div>
              <div className="flex justify-between items-center text-xs pt-1 border-t border-[#e5e5d1]/70">
                <span className="text-[#737366]">{srv.count} Times Sold</span>
                <span className="font-mono font-bold text-[#2d2d2a]">{srv.totalRevenue.toLocaleString()} ETB</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
