import React from 'react';
import {
  Building2,
  GitBranch,
  Layers,
  UserCheck,
  Bot,
  Bell,
  Sparkles,
  ShieldCheck,
  Scissors,
  UserCheck2,
  FileCode2,
  Tv,
} from 'lucide-react';
import { PersonaRole, Company, Branch, BusinessUnit } from '../types';

interface NavbarProps {
  currentPersona: PersonaRole;
  setCurrentPersona: (persona: PersonaRole) => void;
  companies: Company[];
  selectedCompany: Company;
  setSelectedCompany: (cmp: Company) => void;
  branches: Branch[];
  selectedBranch: Branch;
  setSelectedBranch: (br: Branch) => void;
  businessUnits: BusinessUnit[];
  selectedBusinessUnit: BusinessUnit | null;
  setSelectedBusinessUnit: (bu: BusinessUnit | null) => void;
  onOpenAiAssistant: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentPersona,
  setCurrentPersona,
  companies,
  selectedCompany,
  setSelectedCompany,
  branches,
  selectedBranch,
  setSelectedBranch,
  businessUnits,
  selectedBusinessUnit,
  setSelectedBusinessUnit,
  onOpenAiAssistant,
}) => {
  const filteredBranches = branches.filter((b) => b.companyId === selectedCompany.id);
  const filteredBusinessUnits = businessUnits.filter((bu) => bu.branchId === selectedBranch.id);

  const personaConfig = [
    {
      id: 'saas_super_admin',
      label: 'SaaS Platform Owner',
      icon: ShieldCheck,
      color: 'bg-purple-600 text-white',
    },
    {
      id: 'tenant_admin',
      label: 'Tenant Executive',
      icon: Building2,
      color: 'bg-indigo-600 text-white',
    },
    {
      id: 'receptionist',
      label: 'Receptionist POS',
      icon: Scissors,
      color: 'bg-emerald-600 text-white',
    },
    {
      id: 'staff_member',
      label: 'Staff Portal',
      icon: UserCheck2,
      color: 'bg-amber-600 text-white',
    },
    {
      id: 'architect_lead',
      label: 'Architecture Blueprint',
      icon: FileCode2,
      color: 'bg-slate-800 text-white',
    },
    {
      id: 'queue_tv',
      label: 'TV Waiting Room Queue',
      icon: Tv,
      color: 'bg-amber-700 text-white',
    },
  ];

  return (
    <header id="app-navbar" className="bg-[#5A5A40] border-b border-[#4a4a35] text-[#f5f5f0] sticky top-0 z-40 shadow-md">
      {/* Top Banner Context Switcher Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex flex-wrap items-center justify-between gap-3 border-b border-[#4a4a35]">
        {/* Brand & App Title */}
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-full bg-[#f5f5f0] flex items-center justify-center text-[#5A5A40] font-serif font-bold text-xl shadow-sm">
            S
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-lg font-serif font-light text-[#f5f5f0]">
                Serenity Salon & Spa ERP <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-[#f5f5f0]/15 text-[#f5f5f0] border border-[#f5f5f0]/30 uppercase tracking-widest font-sans font-bold">SaaS</span>
              </h1>
            </div>
            <p className="text-[11px] text-[#f5f5f0]/70 hidden sm:block font-sans">
              Multi-Tenant Multi-Branch Management • Natural Tones Edition
            </p>
          </div>
        </div>

        {/* Multi-Tenant Scoping Filters */}
        {currentPersona !== 'saas_super_admin' && (
          <div className="flex items-center flex-wrap gap-2 text-xs font-sans">
            {/* Company Filter */}
            <div className="flex items-center space-x-1.5 bg-[#f5f5f0]/10 px-3 py-1.5 rounded-full border border-[#f5f5f0]/20 text-[#f5f5f0]">
              <Building2 className="w-3.5 h-3.5 text-[#f5f5f0]/80" />
              <select
                id="company-select"
                value={selectedCompany.id}
                onChange={(e) => {
                  const cmp = companies.find((c) => c.id === e.target.value);
                  if (cmp) setSelectedCompany(cmp);
                }}
                className="bg-transparent text-[#f5f5f0] font-medium outline-none cursor-pointer text-xs"
              >
                {companies.map((c) => (
                  <option key={c.id} value={c.id} className="bg-[#5A5A40] text-[#f5f5f0]">
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Branch Filter */}
            <div className="flex items-center space-x-1.5 bg-[#f5f5f0]/10 px-3 py-1.5 rounded-full border border-[#f5f5f0]/20 text-[#f5f5f0]">
              <GitBranch className="w-3.5 h-3.5 text-[#f5f5f0]/80" />
              <select
                id="branch-select"
                value={selectedBranch.id}
                onChange={(e) => {
                  const br = branches.find((b) => b.id === e.target.value);
                  if (br) setSelectedBranch(br);
                }}
                className="bg-transparent text-[#f5f5f0] font-medium outline-none cursor-pointer text-xs"
              >
                {filteredBranches.map((b) => (
                  <option key={b.id} value={b.id} className="bg-[#5A5A40] text-[#f5f5f0]">
                    {b.name} ({b.city})
                  </option>
                ))}
              </select>
            </div>

            {/* Business Unit Filter */}
            <div className="flex items-center space-x-1.5 bg-[#f5f5f0]/10 px-3 py-1.5 rounded-full border border-[#f5f5f0]/20 text-[#f5f5f0]">
              <Layers className="w-3.5 h-3.5 text-[#f5f5f0]/80" />
              <select
                id="unit-select"
                value={selectedBusinessUnit?.id || ''}
                onChange={(e) => {
                  const bu = businessUnits.find((u) => u.id === e.target.value);
                  setSelectedBusinessUnit(bu || null);
                }}
                className="bg-transparent text-[#f5f5f0] font-medium outline-none cursor-pointer text-xs"
              >
                <option value="" className="bg-[#5A5A40] text-[#f5f5f0]">
                  All Business Units
                </option>
                {filteredBusinessUnits.map((bu) => (
                  <option key={bu.id} value={bu.id} className="bg-[#5A5A40] text-[#f5f5f0]">
                    {bu.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
        )}

        {/* AI Assistant Quick Trigger */}
        <div className="flex items-center space-x-2">
          <button
            id="open-ai-assistant-btn"
            onClick={onOpenAiAssistant}
            className="flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-[#f5f5f0] hover:bg-white text-[#5A5A40] text-xs font-semibold transition-all shadow-sm cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#5A5A40]" />
            <span className="hidden md:inline font-sans">Gemini ERP AI</span>
          </button>
        </div>
      </div>

      {/* Persona View Mode Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2.5 flex items-center justify-between overflow-x-auto gap-2">
        <div className="text-xs text-[#f5f5f0]/70 font-medium uppercase tracking-wider whitespace-nowrap flex items-center space-x-1.5">
          <UserCheck className="w-3.5 h-3.5" />
          <span>Persona:</span>
        </div>

        <div className="flex items-center space-x-2 overflow-x-auto py-0.5">
          {personaConfig.map((item) => {
            const Icon = item.icon;
            const isActive = currentPersona === item.id;
            return (
              <button
                key={item.id}
                id={`persona-btn-${item.id}`}
                onClick={() => setCurrentPersona(item.id as PersonaRole)}
                className={`flex items-center space-x-1.5 px-3.5 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-all cursor-pointer ${
                  isActive
                    ? 'bg-[#f5f5f0] text-[#5A5A40] font-bold shadow-sm'
                    : 'bg-[#f5f5f0]/10 text-[#f5f5f0]/80 hover:bg-[#f5f5f0]/20 hover:text-white border border-[#f5f5f0]/15'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
