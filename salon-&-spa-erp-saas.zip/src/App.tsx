import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { SaasAdminDashboard } from './components/SaasAdminDashboard';
import { TenantAdminView } from './components/TenantAdminView';
import { ReceptionistPos } from './components/ReceptionistPos';
import { StaffPortalView } from './components/StaffPortalView';
import { ArchitectBlueprintView } from './components/ArchitectBlueprintView';
import { QueueDisplayView } from './components/QueueDisplayView';
import { AiAssistantModal } from './components/AiAssistantModal';

import {
  mockCompanies,
  mockBranches,
  mockBusinessUnits,
  mockStaff,
  mockServices,
  mockCustomers,
  mockVisitSessions,
  mockCommissionLogs,
  mockCommissionRules,
  mockInventoryItems,
  mockExpenses,
  mockSmsLogs,
  mockAuditLogs,
  mockSubscriptionPlans,
  mockArchitectureSections,
} from './data/mockErpData';

import {
  PersonaRole,
  Company,
  Branch,
  BusinessUnit,
  Staff,
  Service,
  Customer,
  VisitSession,
  CommissionLog,
  CommissionRule,
  InventoryItem,
  ExpenseRecord,
  SmsLog,
  AuditLog,
  PaymentMethod,
} from './types';

export default function App() {
  // Active Persona State
  const [currentPersona, setCurrentPersona] = useState<PersonaRole>('receptionist');

  // Multi-Tenant State Collections
  const [companies, setCompanies] = useState<Company[]>(mockCompanies);
  const [selectedCompany, setSelectedCompany] = useState<Company>(mockCompanies[0]);

  const [branches, setBranches] = useState<Branch[]>(mockBranches);
  const [selectedBranch, setSelectedBranch] = useState<Branch>(mockBranches[0]);

  const [businessUnits, setBusinessUnits] = useState<BusinessUnit[]>(mockBusinessUnits);
  const [selectedBusinessUnit, setSelectedBusinessUnit] = useState<BusinessUnit | null>(
    mockBusinessUnits[0]
  );

  const [staffList, setStaffList] = useState<Staff[]>(mockStaff);
  const [services, setServices] = useState<Service[]>(mockServices);
  const [customers, setCustomers] = useState<Customer[]>(mockCustomers);
  const [visitSessions, setVisitSessions] = useState<VisitSession[]>(mockVisitSessions);
  const [commissionLogs, setCommissionLogs] = useState<CommissionLog[]>(mockCommissionLogs);
  const [commissionRules, setCommissionRules] = useState<CommissionRule[]>(mockCommissionRules);
  const [inventoryItems, setInventoryItems] = useState<InventoryItem[]>(mockInventoryItems);
  const [expenses, setExpenses] = useState<ExpenseRecord[]>(mockExpenses);
  const [smsLogs, setSmsLogs] = useState<SmsLog[]>(mockSmsLogs);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(mockAuditLogs);

  // Gemini AI Assistant Modal
  const [isAiModalOpen, setIsAiModalOpen] = useState(false);

  // HANDLERS FOR CREATING / UPDATING ENTITIES
  const handleAddCompany = (newCompany: Company) => {
    setCompanies((prev) => [newCompany, ...prev]);
    setSelectedCompany(newCompany);
  };

  const handleAddBranch = (newBranch: Branch) => {
    setBranches((prev) => [...prev, newBranch]);
    setSelectedBranch(newBranch);
  };

  const handleAddBusinessUnit = (newUnit: BusinessUnit) => {
    setBusinessUnits((prev) => [...prev, newUnit]);
    setSelectedBusinessUnit(newUnit);
  };

  const handleAddStaff = (newStaff: Staff) => {
    setStaffList((prev) => [...prev, newStaff]);
  };

  const handleAddService = (newService: Service) => {
    setServices((prev) => [...prev, newService]);
  };

  const handleAddInventoryItem = (newItem: InventoryItem) => {
    setInventoryItems((prev) => [...prev, newItem]);
  };

  const handleAddExpense = (newExpense: ExpenseRecord) => {
    setExpenses((prev) => [newExpense, ...prev]);
    const audit: AuditLog = {
      id: `aud_${Date.now()}_${Math.random().toString().slice(-4)}`,
      companyId: newExpense.companyId,
      branchId: newExpense.branchId,
      actionType: 'expense_added',
      description: `Expense Recorded: ${newExpense.description} (${newExpense.amountEtb.toLocaleString()} ETB)`,
      performedBy: newExpense.recordedBy || 'Tenant Admin',
      timestamp: new Date().toISOString(),
      details: newExpense.isRecurring
        ? `Recurring (${newExpense.recurrenceFrequency || 'monthly'}), Next Due: ${newExpense.nextDueDate || 'Next Cycle'}`
        : 'One-time expense record',
      ipAddress: '197.156.102.14',
    };
    setAuditLogs((prev) => [audit, ...prev]);
  };

  const handleAddAuditLog = (newLog: AuditLog) => {
    setAuditLogs((prev) => [newLog, ...prev]);
  };

  const handleUpdateInventoryStock = (invId: string, addedStock: number) => {
    let itemName = 'Inventory Item';
    setInventoryItems((prev) =>
      prev.map((item) => {
        if (item.id === invId) {
          itemName = item.name;
          return {
            ...item,
            currentStock: item.currentStock + addedStock,
            lastRestockedAt: new Date().toISOString().split('T')[0],
          };
        }
        return item;
      })
    );

    const audit: AuditLog = {
      id: `aud_${Date.now()}_${Math.random().toString().slice(-4)}`,
      companyId: selectedCompany.id,
      branchId: selectedBranch.id,
      actionType: 'inventory_adjustment',
      description: `Stock Adjustment / Restock: ${itemName} (+${addedStock} units)`,
      performedBy: 'Tenant Admin',
      timestamp: new Date().toISOString(),
      details: `Updated inventory quantity for Item ID ${invId}`,
      ipAddress: '197.156.102.14',
    };
    setAuditLogs((prev) => [audit, ...prev]);
  };

  const handleAddCustomer = (newCust: Customer) => {
    setCustomers((prev) => [newCust, ...prev]);
  };

  const handleCreateVisitSession = (newSession: VisitSession) => {
    setVisitSessions((prev) => [newSession, ...prev]);
  };

  const handleUpdateSessionStatus = (
    sessionId: string,
    newStatus: 'queued' | 'in_progress' | 'completed' | 'cancelled'
  ) => {
    const session = visitSessions.find((s) => s.id === sessionId);
    if (!session) return;

    setVisitSessions((prev) =>
      prev.map((s) => (s.id === sessionId ? { ...s, status: newStatus } : s))
    );

    // Auto-trigger Mock SMS notification
    if (newStatus === 'in_progress') {
      const sms: SmsLog = {
        id: `sms_${Date.now()}_${Math.random().toString().slice(-4)}`,
        companyId: session.companyId,
        recipientPhone: session.customerPhone,
        messageType: 'queue_turn_alert',
        content: `${selectedCompany.name}: Hello ${session.customerName}! Queue #${session.queueNumber} is now IN PROGRESS. Station ready for ${session.services.map((s) => s.serviceName).join(', ')}.`,
        status: 'sent',
        sentAt: new Date().toISOString(),
      };
      setSmsLogs((prev) => [sms, ...prev]);
    } else if (newStatus === 'completed') {
      const sms: SmsLog = {
        id: `sms_${Date.now()}_${Math.random().toString().slice(-4)}`,
        companyId: session.companyId,
        recipientPhone: session.customerPhone,
        messageType: 'session_receipt',
        content: `${selectedCompany.name}: Hello ${session.customerName}, session #${session.queueNumber} is COMPLETED! Total: ${session.netTotalEtb} ETB. Thank you for visiting!`,
        status: 'sent',
        sentAt: new Date().toISOString(),
      };
      setSmsLogs((prev) => [sms, ...prev]);
    }
  };

  const handleUpdateSessionTimeOrStaff = (
    sessionId: string,
    newStaffId: string,
    newTime: string
  ) => {
    setVisitSessions((prev) =>
      prev.map((s) => {
        if (s.id !== sessionId) return s;
        const stf = staffList.find((st) => st.id === newStaffId);
        return {
          ...s,
          services: s.services.map((srv) => ({
            ...srv,
            staffId: newStaffId,
            staffName: stf?.name || srv.staffName,
          })),
        };
      })
    );
  };

  const handleSaveCommissionRule = (newRule: CommissionRule) => {
    setCommissionRules((prev) => {
      const idx = prev.findIndex(
        (r) =>
          r.companyId === newRule.companyId &&
          r.targetType === newRule.targetType &&
          r.targetId === newRule.targetId
      );
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = newRule;
        return copy;
      }
      return [newRule, ...prev];
    });

    const audit: AuditLog = {
      id: `aud_${Date.now()}_${Math.random().toString().slice(-4)}`,
      companyId: newRule.companyId,
      branchId: selectedBranch.id,
      actionType: 'commission_change',
      description: `Commission Rule Configured: ${newRule.targetName} (${newRule.value}${newRule.type === 'percentage' ? '%' : ' ETB'})`,
      performedBy: 'Tenant Admin',
      timestamp: new Date().toISOString(),
      details: `Rule Type: ${newRule.type.toUpperCase()}, Target: ${newRule.targetType.toUpperCase()}`,
      ipAddress: '197.156.102.14',
    };
    setAuditLogs((prev) => [audit, ...prev]);
  };

  const handleCheckoutSession = (
    sessionId: string,
    paymentMethod: PaymentMethod,
    reference: string
  ) => {
    const session = visitSessions.find((s) => s.id === sessionId);
    if (!session) return;

    // 1. Update session status to completed
    setVisitSessions((prev) =>
      prev.map((s) =>
        s.id === sessionId
          ? {
              ...s,
              status: 'completed',
              isPaid: true,
              paymentMethod,
              paymentReference: reference,
              completedAt: new Date().toISOString(),
              services: s.services.map((srv) => ({ ...srv, status: 'completed' })),
            }
          : s
      )
    );

    // 2. Grant Customer Loyalty Points (1 point per 10 ETB net spent)
    const pointsEarned = Math.floor(session.netTotalEtb / 10);
    setCustomers((prev) =>
      prev.map((c) => {
        if (c.id === session.customerId || c.phone === session.customerPhone) {
          const newTotalSpent = c.totalSpentEtb + session.netTotalEtb;
          const newVisits = c.totalVisits + 1;
          const newPoints = (c.loyaltyPoints || 0) + pointsEarned;
          return {
            ...c,
            totalSpentEtb: newTotalSpent,
            totalVisits: newVisits,
            loyaltyPoints: newPoints,
            isVip: newTotalSpent >= 10000 || newVisits >= 10,
          };
        }
        return c;
      })
    );

    // 3. Auto-Deduct inventory and generate staff commissions based on active rules
    session.services.forEach((serviceItem) => {
      const srv = services.find((s) => s.id === serviceItem.serviceId);
      if (srv) {
        srv.requiredInventory.forEach((req) => {
          setInventoryItems((prev) =>
            prev.map((inv) =>
              inv.id === req.inventoryItemId
                ? { ...inv, currentStock: Math.max(0, inv.currentStock - req.quantityUsed) }
                : inv
            )
          );
        });
      }

      // Append staff commission log using configured rules
      const stf = staffList.find((s) => s.id === serviceItem.staffId);

      // Rule lookup priority: Staff rule takes precedence over Service rule
      const staffRule = commissionRules.find(
        (r) =>
          r.companyId === session.companyId &&
          r.targetType === 'staff' &&
          r.targetId === serviceItem.staffId &&
          r.isActive
      );
      const serviceRule = commissionRules.find(
        (r) =>
          r.companyId === session.companyId &&
          r.targetType === 'service' &&
          r.targetId === serviceItem.serviceId &&
          r.isActive
      );

      const activeRule = staffRule || serviceRule;
      let calculatedCommission = 0;
      let ruleAppliedLabel = '';

      if (activeRule) {
        if (activeRule.type === 'percentage') {
          calculatedCommission = Math.round((serviceItem.priceEtb * activeRule.value) / 100);
          ruleAppliedLabel = `${activeRule.value}% ${
            activeRule.targetType === 'staff' ? 'Staff Custom' : 'Service Custom'
          } Rule`;
        } else {
          calculatedCommission = activeRule.value;
          ruleAppliedLabel = `${activeRule.value.toLocaleString()} ETB Fixed ${
            activeRule.targetType === 'staff' ? 'Staff' : 'Service'
          } Rate`;
        }
      } else {
        const defaultPct = stf?.defaultCommissionPercentage || 30;
        calculatedCommission = Math.round((serviceItem.priceEtb * defaultPct) / 100);
        ruleAppliedLabel = `${defaultPct}% Standard Rate`;
      }

      const commLog: CommissionLog = {
        id: `com_${Date.now()}_${Math.random().toString().slice(-4)}`,
        companyId: session.companyId,
        branchId: session.branchId,
        staffId: serviceItem.staffId,
        staffName: serviceItem.staffName,
        visitSessionId: session.id,
        serviceName: serviceItem.serviceName,
        servicePriceEtb: serviceItem.priceEtb,
        commissionAmountEtb: calculatedCommission,
        ruleApplied: ruleAppliedLabel,
        payoutStatus: 'unpaid',
        createdAt: new Date().toISOString(),
      };

      setCommissionLogs((prev) => [commLog, ...prev]);
    });

    // 4. Record Security Audit Log
    const audit: AuditLog = {
      id: `aud_${Date.now()}_${Math.random().toString().slice(-4)}`,
      companyId: session.companyId,
      branchId: session.branchId,
      actionType: 'payment_edit',
      description: `Payment Checkout Completed: Session #${session.queueNumber} (${session.netTotalEtb} ETB via ${paymentMethod.toUpperCase()})`,
      performedBy: 'Receptionist POS',
      timestamp: new Date().toISOString(),
      details: `Ref: ${reference || 'N/A'}. Granted +${pointsEarned} Loyalty Points to ${session.customerName}`,
      ipAddress: '197.156.102.88',
    };
    setAuditLogs((prev) => [audit, ...prev]);

    // 5. Queue SMS receipt log
    const sms: SmsLog = {
      id: `sms_${Date.now()}`,
      companyId: session.companyId,
      recipientPhone: session.customerPhone,
      messageType: 'session_receipt',
      content: `${selectedCompany.name}: Thank you ${session.customerName}! Session ${session.queueNumber} complete. Paid ${session.netTotalEtb} ETB via ${paymentMethod.toUpperCase()} (Ref: ${reference}). You earned +${pointsEarned} Loyalty Points!`,
      status: 'sent',
      sentAt: new Date().toISOString(),
    };
    setSmsLogs((prev) => [sms, ...prev]);
  };

  return (
    <div id="app-root" className="min-h-screen bg-[#f5f5f0] text-[#2d2d2a] flex flex-col font-sans antialiased selection:bg-[#5A5A40] selection:text-white">
      {/* Top Navbar */}
      <Navbar
        currentPersona={currentPersona}
        setCurrentPersona={setCurrentPersona}
        companies={companies}
        selectedCompany={selectedCompany}
        setSelectedCompany={setSelectedCompany}
        branches={branches}
        selectedBranch={selectedBranch}
        setSelectedBranch={setSelectedBranch}
        businessUnits={businessUnits}
        selectedBusinessUnit={selectedBusinessUnit}
        setSelectedBusinessUnit={setSelectedBusinessUnit}
        onOpenAiAssistant={() => setIsAiModalOpen(true)}
      />

      {/* Main Container Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {currentPersona === 'saas_super_admin' && (
          <SaasAdminDashboard
            companies={companies}
            onAddCompany={handleAddCompany}
            subscriptionPlans={mockSubscriptionPlans}
            smsLogs={smsLogs}
          />
        )}

        {currentPersona === 'tenant_admin' && (
          <TenantAdminView
            company={selectedCompany}
            branches={branches}
            businessUnits={businessUnits}
            staffList={staffList}
            services={services}
            inventoryItems={inventoryItems}
            commissionLogs={commissionLogs}
            commissionRules={commissionRules}
            expenses={expenses}
            visitSessions={visitSessions}
            auditLogs={auditLogs}
            selectedBranch={selectedBranch}
            onAddBranch={handleAddBranch}
            onAddBusinessUnit={handleAddBusinessUnit}
            onAddStaff={handleAddStaff}
            onAddService={handleAddService}
            onAddInventoryItem={handleAddInventoryItem}
            onUpdateInventoryStock={handleUpdateInventoryStock}
            onSaveCommissionRule={handleSaveCommissionRule}
            onAddExpense={handleAddExpense}
            onAddAuditLog={handleAddAuditLog}
          />
        )}

        {currentPersona === 'receptionist' && (
          <ReceptionistPos
            company={selectedCompany}
            branch={selectedBranch}
            businessUnit={selectedBusinessUnit}
            staffList={staffList}
            services={services}
            customers={customers}
            visitSessions={visitSessions}
            inventoryItems={inventoryItems}
            smsLogs={smsLogs}
            onCreateVisitSession={handleCreateVisitSession}
            onCheckoutSession={handleCheckoutSession}
            onAddCustomer={handleAddCustomer}
            onUpdateSessionStatus={handleUpdateSessionStatus}
            onUpdateSessionTimeOrStaff={handleUpdateSessionTimeOrStaff}
          />
        )}

        {currentPersona === 'queue_tv' && (
          <QueueDisplayView
            company={selectedCompany}
            branch={selectedBranch}
            visitSessions={visitSessions}
            onExitTvMode={() => setCurrentPersona('receptionist')}
          />
        )}

        {currentPersona === 'staff_member' && (
          <StaffPortalView
            staffList={staffList}
            commissionLogs={commissionLogs}
            visitSessions={visitSessions}
            branches={branches}
            businessUnits={businessUnits}
          />
        )}

        {currentPersona === 'architect_lead' && (
          <ArchitectBlueprintView sections={mockArchitectureSections} />
        )}
      </main>

      {/* Footer */}
      <footer id="app-footer" className="bg-white border-t border-[#e5e5d1] py-4 text-xs text-[#737366] text-center">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div>
            <strong className="text-[#5A5A40] font-serif font-bold">Serenity Salon & Spa Management ERP SaaS</strong> — Multi-Tenant Multi-Branch Platform
          </div>
          <div className="text-[11px] uppercase tracking-wider font-semibold text-[#5A5A40]/70">
            Natural Tones • Laravel 11 • Single DB Multi-Tenancy • ETB Currency
          </div>
        </div>
      </footer>

      {/* Gemini AI Assistant Modal */}
      <AiAssistantModal
        isOpen={isAiModalOpen}
        onClose={() => setIsAiModalOpen(false)}
        selectedCompany={selectedCompany}
        selectedBranch={selectedBranch}
      />
    </div>
  );
}
